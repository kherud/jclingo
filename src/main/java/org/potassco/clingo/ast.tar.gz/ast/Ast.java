package org.potassco.clingo.ast;

import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.PointerByReference;
import org.potassco.clingo.Clingo;
import org.potassco.clingo.ErrorChecking;
import org.potassco.clingo.args.AttributeType;
import org.potassco.clingo.symbol.Symbol;

import java.util.NoSuchElementException;

/**
 * Represents a node in the abstract syntax tree.
 *
 * The attributes of an `AST` are tied to its type.
 *
 * Furthermore, AST nodes implement comparison operators and are
 * ordered structurally ignoring the location. Their string representation
 * corresponds to their gringo representation. In fact, the string
 * representation of any AST obtained from `parse_files` and `parse_string`
 * can be parsed again. Note that it is possible to construct ASTs
 * that are not parsable, though.
 */
public class Ast implements Comparable<Ast>, ErrorChecking {

    private final Pointer ast;

    public Ast(Pointer ast) {
        this.ast = ast;
    }

    public String getString() {
        String[] stringByReference = new String[1];
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_string(ast, AttributeType.STRING.getValue(), stringByReference));
        return stringByReference[0];
    }

    public int getNumber() {
        IntByReference intByReference = new IntByReference();
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_number(ast, AttributeType.NUMBER.getValue(), intByReference));
        return intByReference.getValue();
    }

    public Symbol getSymbol() {
        LongByReference longByReference = new LongByReference();
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_symbol(ast, AttributeType.AST.getValue(), longByReference));
        return Symbol.fromLong(longByReference.getValue());
    }

    public Location getLocation() {
        Location.ByReference locationByReference = new Location.ByReference();
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_location(ast, AttributeType.LOCATION.getValue(), locationByReference));
        return locationByReference;
    }

    public Ast getOptionalAst() {
        PointerByReference pointerByReference = new PointerByReference();
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_optional_ast(ast, AttributeType.OPTIONAL_AST.getValue(), pointerByReference));
        if (pointerByReference.getValue() == null)
            throw new NoSuchElementException("there is no optional ast");
        return new Ast(pointerByReference.getValue());
    }

    public Ast getAst() {
        PointerByReference pointerByReference = new PointerByReference();
        checkError(Clingo.INSTANCE.clingo_ast_attribute_get_ast(ast, AttributeType.AST.getValue(), pointerByReference));
        return new Ast(pointerByReference.getValue());
    }

    public StringSequence getStringArray() {
        return new StringSequence(ast);
    }

    public AstSequence getAstArray() {
        return new AstSequence(ast);
    }

    /**
     * Decrement the reference count of an AST node.
     * The node is deleted if the reference count reaches zero.
     */
    public void release() {
        Clingo.INSTANCE.clingo_ast_release(ast);
    }

    /**
     * Equality compare two AST nodes.
     * @param other the right-hand-side AST
     * @return the result of the compariso
     */
    public boolean equals(Ast other) {
        return Clingo.INSTANCE.clingo_ast_equal(ast, other.getPointer());
    }

    /**
     * Less than compare two AST nodes.
     * @param other the right-hand-side AST
     * @return the result of the compariso
     */
    public boolean isLess(Ast other) {
        return Clingo.INSTANCE.clingo_ast_less_than(ast, other.getPointer());
    }

    @Override
    public int compareTo(Ast other) {
        return equals(other) ? 0 : isLess(other) ? -1 : 1;
    }

    public Pointer getPointer() {
        return ast;
    }

}
