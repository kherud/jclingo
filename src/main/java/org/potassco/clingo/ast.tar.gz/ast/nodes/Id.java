package org.potassco.clingo.ast.nodes;

import org.potassco.clingo.Clingo;
import org.potassco.clingo.ast.Location;

public class Id {

    public Id(Location location, String name) {
        Clingo.INSTANCE.clingo_ast_build()

    }
}
